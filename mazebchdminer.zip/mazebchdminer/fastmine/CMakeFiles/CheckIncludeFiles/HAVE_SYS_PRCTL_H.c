/* */
#include <sys/prctl.h>


int main(void){return 0;}

