### Mazebchdminer is a version of Mist miner - bchd_mist_miner_v1 (from https://mistcoin.org), prepared for mining MAZE (https://mazetoken.github.io) and patched for BigNumber error and dust input attack (https://gitlab.com/blue_mist/miner/-/commit/e64b1440619589483c3b38870e5cafb791448045). Mazebchdminer has preinstalled fastmine files for linux and windows - no need to run any command for fastmine.

You can mine other tokens (Mist, dSLP, BTCL) with this miner too. To do this you need to:
- change .env file in mazebchdminer folder for other token environment (see below),
- delete .cache file from mazebchdminer folder,
- delete cache.js and cache.js.map files from mazebchdminer src folder (if you have node_modules already installed in mazebchdminer folder).
Before you start mining other token you can paste .cache file for the token you want to mine to speed up downloading txid (token txid are stored in .cache file; make sure that there is a dot before cache file name).

For mining tutorial go here https://github.com/mazetoken/mining
You can get .cache files for different tokens from this ^ repository - tokenscache folder

Fastmine for dSLP is set to "no" by default - fastmine doesn`t work well with dSLP, because difficulty is set to: 2 for dSLP. We don`t need fastmine for dSLP - mining speed is similiar to other tokens where fastmine is set to "yes"

B_S_Z

--------------------------------------------------------------------------------------
Other tokens environment

Mist:

TOKEN_INIT_REWARD_V1=400000000
TOKEN_HALVING_INTERVAL_V1=4320
MINER_DIFFICULTY_V1=3
MINER_UTF8=""
TOKEN_START_BLOCK_V1=639179
TOKEN_ID_V1="d6876f0fce603be43f15d34348bb1de1a8d688e1152596543da033a060cff798"
USE_FASTMINE="yes"

dSLP:

TOKEN_INIT_REWARD_V1=2000000
TOKEN_HALVING_INTERVAL_V1=6480
MINER_DIFFICULTY_V1=2
MINER_UTF8=""
TOKEN_START_BLOCK_V1=653104
TOKEN_ID_V1="5aa6c9485f746cddfb222cba6e215ab2b2d1a02f3c2506774b570ed40c1206e8"
USE_FASTMINE="no"

BTCL:

TOKEN_INIT_REWARD_V1=800000000
TOKEN_HALVING_INTERVAL_V1=4320
MINER_DIFFICULTY_V1=3
MINER_UTF8=""
TOKEN_START_BLOCK_V1=655223
TOKEN_ID_V1="20e8e13347a76f6041bf7d31b04a7bbb7e2deb5d95e15ae8619179b3552ca02a"
USE_FASTMINE="yes"