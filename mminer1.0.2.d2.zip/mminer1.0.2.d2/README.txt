### Mminer 1.0.2 - miner difficulty 2

_Update by [B_S_Z](https://t.me/b_s_z) - https://mazetoken.github.io_

You can create a mineable SLP tokens (based on Mist covenant contract script) and mine it with Mminer

Mminer is an updated version of Mist miner - bchd_mist_miner_v1 (https://mistcoin.org) prepared for mining dSLP SLP Token Type 1

What is updated:

- Mminer is patched for "bn not an integer" error and "dust input attack" (the patch is from https://gitlab.com/blue_mist/miner)

- package.json - npm packages (e.g. slpjs 0.27.11)

- generateV1.ts - Mminer works with a modified* grpc-bchrpc-node 0.11.3 (https://github.com/simpleledgerinc)

_*SkipSlpValidityChecks is set to "true" and should be set to "false" when BCHD instances support SLP indexing)_


Go to https://github.com/mazetoken/mminer for new releases, mining tutorial and mineable tokens environment

